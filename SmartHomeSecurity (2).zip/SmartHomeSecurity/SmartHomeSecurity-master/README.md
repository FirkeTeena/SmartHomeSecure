# SmartHomeSecurity

1:video being store and downtream at apache server.



2:At hardware side video upstreaming and at server video is being recieved and dumped in apache using python language.



3:locker code have been written in embedded c.



4:Admin server is written in node and UI for admin(controll system) is written in Angular  which is in UI folder.

5:FCM server( server to push the notifications) is written in nodejs.


6:User Client is written as an andriod application which is in SHSecuirity folder.


7:users infermation is being stored in mongodb.


Thankyou
